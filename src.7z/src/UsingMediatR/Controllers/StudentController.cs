﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using UsingMediatR.Logic;

namespace UsingMediatR.Controllers
{
    [Route("api/[controller]")]
    public class StudentController : Controller
    {
        private readonly IMediator mediator;

        public StudentController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        // GET api/student
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var query = new StudentQuery();

            var response = await mediator.Send(query);

            if (response.IsFailure)
                return BadRequest(response.Error);

            return Ok(response.Value);
        }
    }
}
