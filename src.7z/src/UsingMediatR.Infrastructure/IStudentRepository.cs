﻿using System.Collections.Generic;
using UsingMediatR.Core;
using UsingMediatR.Domain;

namespace UsingMediatR.Infrastructure
{
    public interface IStudentRepository
    {
        Maybe<IEnumerable<Student>> Get();
    }
}
