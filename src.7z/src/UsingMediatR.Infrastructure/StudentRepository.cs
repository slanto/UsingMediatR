﻿using System.Collections.Generic;
using UsingMediatR.Core;
using UsingMediatR.Domain;

namespace UsingMediatR.Infrastructure
{
    public class StudentRepository : IStudentRepository
    {
        public Maybe<IEnumerable<Student>> Get()
        {
            return new List<Student>();
        }
    }
}
