﻿using UsingMediatR.Core;

namespace UsingMediatR.Domain
{
    public class LastName : ValueObject<LastName>
    {
        public string Value { get; }

        private LastName(string value)
        {
            Value = value;
        }

        public static Result<LastName> Create(string lastName)
        {
            if (string.IsNullOrEmpty(lastName) || lastName.Length > 250)
                return Result.Fail<LastName>("Last name is invalid");

            return Result.Ok(new LastName(lastName));
        }

        protected override bool EqualsCore(LastName other)
        {
            return Value.Equals(other);
        }

        protected override int GetHashCodeCore()
        {
            return Value.GetHashCode();
        }

        public static explicit operator LastName(string name)
        {
            return Create(name).Value;
        }

        public static implicit operator string(LastName lastName)
        {
            return lastName.Value;
        }
    }
}
