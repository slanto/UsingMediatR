﻿using UsingMediatR.Core;

namespace UsingMediatR.Domain
{
    public class FirstName : ValueObject<FirstName>
    {
        public string Value { get;  }

        private FirstName(string value)
        {
            Value = value;
        }

        public static Result<FirstName> Create(string name)
        {
            if (string.IsNullOrEmpty(name) || name.Length > 100)
                return Result.Fail<FirstName>("Name is invalid");

            return Result.Ok(new FirstName(name));
        }

        protected override bool EqualsCore(FirstName other)
        {
            return Value.Equals(other);
        }

        protected override int GetHashCodeCore()
        {
            return Value.GetHashCode();
        }

        public static explicit operator FirstName(string name)
        {
            return Create(name).Value;
        }

        public static implicit operator string(FirstName firstName)
        {
            return firstName.Value;
        }
    }
}
