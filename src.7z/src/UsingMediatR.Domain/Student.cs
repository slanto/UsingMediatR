﻿using System;

namespace UsingMediatR.Domain
{
    public class Student
    {
        public FirstName FirstName { get; set; }

        public LastName LastName { get; set; }

        public EmailAddress Email { get; set; }
    }
}
