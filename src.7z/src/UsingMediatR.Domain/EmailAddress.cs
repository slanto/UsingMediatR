﻿namespace UsingMediatR.Domain
{
    public class EmailAddress
    {
    }
}
