﻿using System.Collections.Generic;
using MediatR;
using UsingMediatR.Infrastructure;
using UsingMediatR.Core;
using System;

namespace UsingMediatR.Logic
{
    public class StudentQueryHandler : IRequestHandler<StudentQuery, Result<IEnumerable<Model>>>
    {
        private readonly IStudentRepository studentRepository;

        public StudentQueryHandler(IStudentRepository studentRepository)
        {
            this.studentRepository = studentRepository;
        }

        public Result<IEnumerable<Model>> Handle(StudentQuery message)
        {
            var foundStudents = studentRepository.Get();
            if (foundStudents.HasNoValue)
                return Result.Fail<IEnumerable<Model>>("Not found");

            var students = new List<Model>();
            //map domain student to student DTO
            foreach (var student in foundStudents.Value)
            {
                students.Add(new Model
                {
                    FirstName = student.FirstName,
                    LastName = student.LastName
                });
            }
            return Result.Ok<IEnumerable<Model>>(students);
        }
    }
}
