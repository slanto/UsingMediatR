﻿using System.Collections.Generic;
using MediatR;
using UsingMediatR.Core;

namespace UsingMediatR.Logic
{
    public class StudentQuery : IRequest<Result<IEnumerable<Model>>>
    {

    }
}
